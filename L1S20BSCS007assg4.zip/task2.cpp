#include<iostream>
#include<fstream>
using namespace std;

bool FileOpen(ifstream&, char*);
int SizeCount(ifstream& fin);
int* FileRead(ifstream&, int*);
void Even(int* D, int&, int&, int S);
void Replacement(int*, int*, int*, int);
void Reset();
void DisplayArr(int*, int);

int main()
{
	ifstream fin;
	char* filename = new char[50];
	int* Data = nullptr;
	int data = 0, Size = 0,Even_Count = 0, Odd_Count = 0;

	cout << "Enter Filename with ext. : ";
	cin >> filename;
	cout << endl;

	if (FileOpen(fin, filename))
	{
		Size = SizeCount(fin);
		fin.close();
        Data = new int[Size];
        fin.open(filename);
		Data = FileRead(fin, Data);
		fin.close();

		cout << "Data      : \t";
		DisplayArr(Data, Size);

		Even(Data, Even_Count, Odd_Count, Size);
		int* EvenData = new int[Even_Count];
		int* OddData = new int[Odd_Count];
		Replacement(Data, EvenData, OddData, Size);			
		cout << "Even Data : \t";
		DisplayArr(EvenData, Even_Count);
		cout << "Odd Data  : \t";
		DisplayArr(OddData, Odd_Count);

		Reset();
	}
	else
	{
		cout << "File Opening is Failed." << endl;
	}

	return 0;
}
bool FileOpen(ifstream& fin, char* filename)
{
	bool flag = true;

	fin.open(filename);
	if (!fin.is_open())
	{
		flag = false;
	}
    return flag;
}
int* FileRead(ifstream& fin, int* Data)
{
	int i = 0;
	while (fin >> *(Data + i))
	{
		i++;
	}
	return Data;
}
int SizeCount(ifstream& fin)
{
	int a = 0, size = 0;
	while (fin >> a)
	{
		size++;
	}
	return size;
}
void Even(int* D, int& Even_Count, int& Odd_Count, int S)
{
	for (int i = 0; i < S; i++)
	{
		if (D[i] % 2 == 0)
		{
			Even_Count++;
		}
		else
		{
			Odd_Count++;
		}
	}
}
void Replacement(int* Data, int* EvenData, int* OddData, int Size)
{
	int j = 0, k = 0;
	for (int i = 0; i < Size; i++)
	{
		if (Data[i] % 2 == 0)
		{
			*(EvenData + j) = Data[i];
			j++;
		}
		else
		{
			*(OddData + k) = Data[i];
			k++;
		}
	}
}
void Reset()
{
	int* ptr = nullptr;
	delete[] ptr;
	ptr = nullptr;
}
void DisplayArr(int* arr, int Size)
{
	for (int i = 0; i < Size; i++)
	{
		cout << arr[i] << " ";
	}
	cout <<"\n \n";
}