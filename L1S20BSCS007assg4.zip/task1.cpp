#include <iostream>
#include <fstream>
using namespace std;
//functions
void readAndSeprateData();
void countAndSave(int*&, int&, int&);
void updateArray(int*&, int&, int&, int);
void reset();
int main()
{
	int size = 0, index = 0;
	int* array = new int[size];

	readAndSeprateData();
	countAndSave(array, size, index);

	cout << "Array of lenght\t:\t";
	for (int i = 0; i < index; i++)
	{
		cout << array[i] << " ";
	}
	cout << endl << endl;

	delete[]array;

	return 0;
}
void readAndSeprateData()
{
	ifstream fin;
	ofstream fout;

	fin.open("Text.txt");
	fout.open("orignalText.txt");

	if (!fin.is_open())
	{
		cout << "\tData.txt is not avilable.\n\n";
		exit(-1);
	}
	else
	{
		char temp = '\0';
		cout << "Text.txt\t:\t";
		while (fin.get(temp))
		{
			cout << temp;
			if ((temp >= 'A' && temp <= 'Z') || (temp >= 'a' && temp <= 'z') || (temp == ' '))
				fout << temp;
		}
	}
	cout <<"\n";
	fin.close();
	fout.close();
}
void countAndSave(int*& arr, int& s, int& i)
{
	ifstream fin;
	fin.open("orignalText.txt");

	if (!fin.is_open())
	{
		cout << "Orignal Data.txt not available.\n\n";
	}
	else
	{
		char temp = '\0';
		int counter = 0;

		cout << "Orignal text\t:\t";
		while (fin.get(temp))
		{
			cout << temp;
			if (temp != ' ')
				counter++;
			if (temp == ' ' && counter > 0)
			{
				//cout << " " << counter << " ";
				updateArray(arr, s, i, counter);
				counter = 0;
			}
		}
	}
	cout << "\n";
	fin.close();
}
void updateArray(int*& Array, int& size, int& idx, int value)
{
	int* temp = new int[size + 1];

	for (int i = 0; i < size; i++)
	{
		temp[i] = Array[i];
	}

	temp[size] = value;

	void reset();

	Array = temp;
	size += 1;
	idx = size;
}
void reset()
{
	int* Array = nullptr;
	delete[] Array;
	Array = nullptr;
}
